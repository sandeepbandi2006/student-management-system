function addStudent() {
    let name = document.getElementName('studentName').value;
    if (!name) return;

    let table = document.getElementById('studentTable');
    let row = table.insertRow();

    row.insertCell(0).innerText = name;
    row.insertCell(1).innerHTML = '<button onclick="mark(this,1)">✔</button>';
    row.insertCell(2).innerHTML = '<button onclick="mark(this,0)">✘</button>';
}

function mark(btn, present) {
    btn.parentElement.innerHTML = present ? "Present" : "Absent";
}
